# Recent

> Commands I recently typed

- Get files created by packages:

`dpkg -L {{package}}`

- On change get info
`tail -F {{path-to-file}}`

- Test nginx and reload if ok

`nginx -t && sudo nginx -s reload`


