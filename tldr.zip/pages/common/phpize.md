# phpize

> Prepare a PHP extension for compiling.

- Prepare the PHP extension in the current directory for compiling:

`phpize`

- Delete files previously created by phpize:

`phpize --clean`
