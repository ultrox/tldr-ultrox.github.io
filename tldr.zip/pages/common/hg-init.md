# hg init

> Create a new repository in the specified directory.

- Initialise a new repository in the current directory:

`hg init`

- Initialise a new repository in the specified directory:

`hg init {{path/to/directory}}`
