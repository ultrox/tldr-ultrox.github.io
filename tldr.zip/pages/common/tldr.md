# tldr

> Simplified man pages.

- Get typical usages of a command (hint: this is how you got here!):

`tldr {{command}}`
