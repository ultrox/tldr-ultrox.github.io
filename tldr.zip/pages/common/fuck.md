# fuck

> Corrects your previous console command.

- Set the `fuck` alias to `thefuck` tool:

`eval "$(thefuck --alias)"`

- Try to match a rule for the previous command:

`fuck`
