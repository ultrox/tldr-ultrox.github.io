# gtop

> System monitoring dashboard for the terminal.

- Show the system stats dashboard:

`gtop`

- Sort by CPU usage:

`c`

- Sort by memory usage:

`m`
