# lumen

> A command line installer for the Lumen micro-framework.

- Create a new Lumen application:

`lumen new {{application_name}}`

- List the available installer commands:

`lumen list`
