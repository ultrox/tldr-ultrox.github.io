# logname 

> Shows the user's login name.

- Display the currently logged in user's name:

`logname`
