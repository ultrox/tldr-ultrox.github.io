# git setup

- If using https until restart
`git config --global credential.helper cache`

- https clean after 1h
`git config --global credential.helper 'cache --timeout=3600'`

- more
`https://help.github.com/articles/caching-your-github-password-in-git/#platform-mac`


