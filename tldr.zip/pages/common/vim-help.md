# vim help

> A simple, fast and user-friendly alternative to find.

- Search all the help files with the :helpgrep command, for example:

`:helpgrep \csearch.\{,12}file`

- Look for help ctrl + R in normal mode

`:h CTRL-R`

- Find what is ctrl+R in insert mode
`:h i_CTRL-R`
